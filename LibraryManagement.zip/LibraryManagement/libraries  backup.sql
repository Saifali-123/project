-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2021 at 05:16 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `libraries`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `A_name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`A_name`, `password`) VALUES
('ahmad', 'ahmad'),
('shafaque', 'sr2001');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `call_no` varchar(5) NOT NULL,
  `b_name` varchar(30) NOT NULL,
  `author` varchar(30) NOT NULL,
  `publisher` varchar(40) NOT NULL,
  `quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`call_no`, `b_name`, `author`, `publisher`, `quantity`) VALUES
('A', 'Let Us C', 'Yashwant Kanetkar', 'E Balaguruswami', 7),
('B', 'Organizational Behaviour', 'Stephin Robbins', 'Robbins', 12),
('C', 'Theory Of Computation', 'D.Ullman', 'Pearson', 10),
('D', 'Data Structures And Algorithms', 'Michael T.Goodrich', 'WILEY', 5),
('E', 'Discrete Mathematics', 'Kenneth H.Rosen', 'Mc Graw Hill', 10),
('F', 'Engineering Mathematics', 'Rs Khurmi', 'S.Chand', 8),
('G', 'Data Base Management System', 'Korth', 'Mc Graw Hill', 7),
('H', 'Digital Logic Design', 'Morris Mano', 'Mc Graw Hill', 5),
('I', 'Operating System', 'Silberscatch,Galvin', 'Wiley', 6),
('J', 'Higher Engineering Mathematics', 'John Bird', 'Newnes', 8),
('K', 'Computer Networking', 'Kurose, Ross', 'Pearson', 11),
('L', 'Compiler Design', 'Jeffery D.Ullman', 'Mc Graw Hill', 6),
('M', 'Introduction to Algorithm', 'Cormen', 'The MIT Press', 8),
('N', 'Programming in C', 'Yashwant Kanetkar', 'E.Balaguruswami', 6),
('O', 'Programming in C++', 'Yashwant Kanetkar', 'E.Balaguruswami', 9);

-- --------------------------------------------------------

--
-- Table structure for table `ebook`
--

CREATE TABLE `ebook` (
  `call_no` varchar(5) NOT NULL,
  `b_name` varchar(100) NOT NULL,
  `author` varchar(30) NOT NULL,
  `publisher` varchar(40) NOT NULL,
  `file_url` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ebook`
--

INSERT INTO `ebook` (`call_no`, `b_name`, `author`, `publisher`, `file_url`) VALUES
('A-3', 'Discrete Mathematics', 'Kenneth H Rossen', 'Mc Graw Hill', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Gate\\Discrete mathematics (rosen kennith).pdf'),
('A-4', 'Data Structure and Algorithm', 'Michael T.Goodrich', 'WILEY', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\5th Semester\\Data Structures and Algorithms in Java, 6th Edition, 2014.pdf'),
('B-2', 'Organisational Behaviour', 'Stephen-Robbins', 'Robbins', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Books reference\\organizational-behavior-stephen-robbins.pdf'),
('C-1', 'Database Management System', 'Korth', 'Mc Graw Hill', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Gate\\DBMS Korth.pdf'),
('C-3', 'Engineering Mechanics', 'RS. Khurmi', 'S.Chand', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Books reference\\RS Khurmi-Engg. Mechanics.pdf'),
('D-2', 'Computer Networking', 'Kurose,Ross', 'Pearson', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Gate\\Computer Network.pdf'),
('F-2', 'Digital Logic Design', 'Morris Mano', 'Mc Graw Hill', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Gate\\Digital Logic Design.pdf'),
('G-1', 'Operating System', 'Silverscatch,Galvin', 'Wiley', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Gate\\Operating System.pdf'),
('K-2', 'Higher Engineering Mathematics', 'John Bird', 'Newnes', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Gate\\Higher Engineering Mathematics.pdf'),
('S-3', 'Theory of Computation', 'D.Ullman', 'Pearson', 'C:\\Users\\SHAFAQUE RAHMAN\\Documents\\Gate\\TOC  (FLAT).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `issued`
--

CREATE TABLE `issued` (
  `call_no` varchar(5) NOT NULL,
  `s_id` varchar(30) NOT NULL,
  `s_name` varchar(30) NOT NULL,
  `s_mobile` varchar(20) NOT NULL,
  `issue_date` varchar(30) NOT NULL,
  `last_date` varchar(30) NOT NULL,
  `ret_status` varchar(10) DEFAULT 'No',
  `reissued` varchar(10) DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issued`
--

INSERT INTO `issued` (`call_no`, `s_id`, `s_name`, `s_mobile`, `issue_date`, `last_date`, `ret_status`, `reissued`) VALUES
('C', '38', 'Sania Perween', '5323647543', '04-06-2021', '19-06-2021', 'No', 'No'),
('F', '6', 'Rajesh Kumar', '4674235774', '04-06-2021', '19-06-2021', 'No', 'Yes'),
('J', '15', 'Kamla Deshmukh', '3423464645', '04-06-2021', '19-06-2021', 'Yes', 'No'),
('L', '38', 'Sania Perween', '4323435432', '04-06-2021', '19-06-2021', 'No', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `L_id` int(11) NOT NULL,
  `L_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `address` varchar(40) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`L_id`, `L_name`, `email`, `contact`, `address`, `password`) VALUES
(1, 'Shafaque Rahman', 'shafaque@gmail.com', '7983648275', 'Gaya,Bihar', 'sha123'),
(2, 'Aaquil Rahman', 'aaquil@gmail.com', '5342359548', 'Gaya,Bihar', 'aaquil123'),
(3, 'Sanam Khan', 'sanam@gmail.com', '5345644323', 'Lucknow', 'sanam123'),
(6, 'Asjad Rahman', 'asjad@gmail.com', '3535295875', 'Gaya,Bihar', 'asjad123'),
(7, 'Asif Rahman', 'asif@gmail.com', '5873937584', 'Gaya,Bihar', 'asif123'),
(8, 'Shabana', 'shabana@gmail.com', '5323242432', 'Ranchi', 'shabana123'),
(9, 'Haniya Amir', 'haniya@gmail.com', '3543532343', 'Islamabad', 'haniya123'),
(10, 'Diksha Kumari', 'diksha@gmail.com', '2342424575', 'Kolkata', 'diksha123'),
(11, 'Ambarin Uzma', 'ambarin@gmail.com', '3454652346', 'Delhi', 'ambarin123'),
(12, 'Priyanka Kumari', 'priyanka@gmail.com', '3553239585', 'Rajasthan', 'priyanka123'),
(13, 'Shubha Lakshmi', 'shubha@gmail.com', '2424565367', 'Hyderabad', 'shubha123'),
(14, 'Sonia Singh', 'sonia@gmail.com', '4232545654', 'patna,Bihar', 'sonia123'),
(15, 'Priya Sinha', 'priya@gmail.com', '5334557544', 'Assam', 'priya123'),
(16, 'Kumar Sinu', 'kumar@gmail.com', '4398476352', 'Punjab', 'kumar123'),
(17, 'Akhil Jain', 'akhil@gmail.com', '8898995678', 'Jalandhar', 'akhil123');

-- --------------------------------------------------------

--
-- Table structure for table `librarianlogin`
--

CREATE TABLE `librarianlogin` (
  `l_name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `librarianlogin`
--

INSERT INTO `librarianlogin` (`l_name`, `password`) VALUES
('Shafaque Rahman', 'sha123');

-- --------------------------------------------------------

--
-- Table structure for table `querydb`
--

CREATE TABLE `querydb` (
  `email` varchar(30) NOT NULL,
  `query` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`password`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`call_no`);

--
-- Indexes for table `ebook`
--
ALTER TABLE `ebook`
  ADD PRIMARY KEY (`call_no`);

--
-- Indexes for table `issued`
--
ALTER TABLE `issued`
  ADD PRIMARY KEY (`call_no`,`s_id`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`L_id`),
  ADD UNIQUE KEY `password` (`password`);

--
-- Indexes for table `librarianlogin`
--
ALTER TABLE `librarianlogin`
  ADD PRIMARY KEY (`password`);

--
-- Indexes for table `querydb`
--
ALTER TABLE `querydb`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `L_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
