/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;

import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.table.*;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import static java.time.temporal.ChronoUnit.DAYS;
import java.util.Locale;
import javax.swing.SwingUtilities;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class ViewIssuedBook extends JFrame {

    JFrame jf;
    JTable t;
    JScrollPane sp;
    int k;

    public ViewIssuedBook() {
        jf = new JFrame("View Issued Books");
        //
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");

            //get no of row in database
            String sql1 = "SELECT count(*) FROM issued ";
            Statement statement1 = conn.createStatement();
            ResultSet result1 = statement1.executeQuery(sql1);
            result1.next();
            k = result1.getInt(1);
            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }

        //
        String[][] data = new String[k][10];
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");

            //get no of row in database
//            String sql1 = "SELECT count(L_id) FROM librarian ";
//            Statement statement1 = conn.createStatement();
//            ResultSet result1 = statement1.executeQuery(sql1);
//            result1.next();
//            int k=result1.getInt(1);
            String sql = "SELECT * FROM issued ";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);

            //Comparing all the value of db and checking for unused one                                                                                                                                                                                                         
            String a1, a2, a3, a4, a5, a6, a7, a8, a9,a11;
            int a, a10, i = 0;
            while (result.next()) {
                a1 = result.getString("call_no");
                //a1  = String.valueOf(a);
                a2 = result.getString("s_id");
                a3 = result.getString("s_name");
                a4 = result.getString("s_mobile");
                a5 = result.getString("issue_date");
                a8 = result.getString("last_date");
//                String s = a8;
                a6 = result.getString("ret_status");
                DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH);
                LocalDate d = LocalDate.parse(a8, format);
                LocalDate now1 = LocalDate.now();
                int f = (int) DAYS.between(d, now1);
                if (f > 0 && a6.equals("No")) {
                    a10 = f;
                } else {
                    a10 = 0;
                }
//                a10 = result.getInt("fine");
                a9 = String.valueOf(a10);
                a11 = result.getString("reissued");
                String sql2 = "SELECT b_name FROM book where call_no = '" + a1 + "'";
                Statement statement2 = conn.createStatement();
                ResultSet result2 = statement2.executeQuery(sql2);
                result2.next();
//                int b = result2.getInt(1);
                a7 = result2.getString("b_name");
//                String sql2 = "SELECT count(s_id) FROM issued where call_no='" + a1 + "'";
//                Statement statement2 = conn.createStatement();
//                ResultSet result2 = statement2.executeQuery(sql2);
//                result2.next();
//                int c=result2.getInt(1);
//                int q=Integer.parseInt(a5);
//                a6=String.valueOf(q-c);
//               // a6 = result2.getString("available");

                data[i][0] = a1;
                data[i][1] = a7;
                data[i][2] = a2;
                data[i][3] = a3;
                data[i][4] = a4;
                data[i][5] = a5;
                data[i][6] = a8;
                data[i][7] = a9;
                data[i][8] = a6;
                data[i][9] = a11;
                i++;
            }

            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }

        String[] heading = {"Call No", "Book Name", "Student Id", "Name", "Mobile", "Issued Date", "Last Date", "Fine", "Return_status","Reissued"};

        t = new JTable(data, heading);
        t.setFont(new Font("Serif", Font.PLAIN, 20));
        t.setBounds(0, 0, 1000, 1000);

        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        //Set header bold and colored
        JTableHeader th = t.getTableHeader();
        th.setBackground(Color.gray);
        th.setFont(new Font("Serif", Font.BOLD, 15));
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        //set column width
        t.getColumnModel().getColumn(0).setPreferredWidth(80);
        t.getColumnModel().getColumn(1).setPreferredWidth(220);
        t.getColumnModel().getColumn(2).setPreferredWidth(80);
        t.getColumnModel().getColumn(3).setPreferredWidth(180);
        t.getColumnModel().getColumn(4).setPreferredWidth(110);
        t.getColumnModel().getColumn(5).setPreferredWidth(110);
        t.getColumnModel().getColumn(6).setPreferredWidth(110);
        t.getColumnModel().getColumn(7).setPreferredWidth(70);
        t.getColumnModel().getColumn(8).setPreferredWidth(117);
        t.getColumnModel().getColumn(9).setPreferredWidth(80);

        //set Row Height
        t.setRowHeight(35);
        //t.setSize(600,400);
        t.setPreferredScrollableViewportSize(t.getPreferredSize());
        sp = new JScrollPane(t);
        sp.setPreferredSize(new Dimension(1160, 550));
        jf.add(sp);

        jf.pack();
        // jf.setSize(883,876);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);

    }

    public static void main(String args[]) {
        ViewIssuedBook viewIssuedBook = new ViewIssuedBook();
    }
}
