package librarymanagement;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import java.sql.*;
import java.util.EventListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package librarymanagement;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class LibraryManagement extends JFrame implements ActionListener {

    /**
     * @param args the command line arguments
     */
    private Admin ad;
    private Librarian lib;
    JFrame jf;
    JMenuBar mb;
    JMenu m1,m2,m3,m4,m5;
    JMenuItem i1,i2,i3,i4;
    JLabel l1;
//    public void paint(Graphics g) {  
//        Toolkit t=Toolkit.getDefaultToolkit();  
//        Image i=t.getImage("librarymanagement\\lib.jpg");  
//        g.drawImage(i, 0,0,500,500,null);  
//    }
    public LibraryManagement() {
        jf=new JFrame("Library Home Page ");
        m1=new JMenu("Home");
        m2=new JMenu("Contact");
        m3=new JMenu("Help");
        m4=new JMenu("Login");
        m5=new JMenu("E-Books");
        i1=new JMenuItem("Admin Login");
        i2=new JMenuItem("Librarian Login");
        i3=new JMenuItem("Query Help");
        i4=new JMenuItem("Go To Books");
        mb=new JMenuBar();
        m3.add(i3);
        mb.add(m1);
        mb.add(m2);
        mb.add(m3);
        mb.add(m4);
        mb.add(m5);
        m4.add(i1);
        m4.addSeparator();
        m4.add(i2);
        m5.add(i4);
       // mb.setBounds(0,0,600,60);
        //jf.add(mb);
       // p.setBounds(0,0,600,520);
        //jf.add(p);
        jf.setJMenuBar(mb);
        
        jf.setContentPane(new JLabel(new ImageIcon("C:\\Users\\SHAFAQUE RAHMAN\\Documents\\NetBeansProjects\\LibraryManagement\\src\\librarymanagement\\lib.jpg")));
        JLabel l=new JLabel("Welcome To Library");
        l.setBounds(200,100,500,100);
        jf.add(l);
        l.setFont(new Font("Serif", Font.BOLD, 36));
        l.setForeground(Color.YELLOW);

       JLabel l1=new JLabel("Enjoy Your Books");
        l1.setBounds(230,200,500,100);
        jf.add(l1);
        l1.setFont(new Font("Serif", Font.BOLD, 32));
        l1.setForeground(Color.PINK);
        

        
        i1.addActionListener(this);
        i2.addActionListener(this);
        i3.addActionListener(this);
        i4.addActionListener(this);
                
        jf.setVisible(true);
        jf.setSize(800,600);
        
        //To center the frame in window screen
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    @Override 
    public void actionPerformed(ActionEvent e) {
            if(e.getSource()==i1) {
                
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            
            
            String sql1 = "SELECT count(password) FROM adminLogin";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql1);
            //AddLibrarian al2 = new AddLibrarian();
           // JOptionPane.showMessageDialog(al2,"Librarian details has been inserted with id = "+v);
//            while(result.next());
//            result.next();
            result.next();
            int c=result.getInt(1);
//            String u=result.getString(1);
//            String p=result.getString(2);
            System.out.println(c);
            if(c==2) {
                new AdminWork();
                result.first();
            } else {
                new Admin();
            }
            jf.dispose();
            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
                
                
            }
            
            if(e.getSource()==i2) {
                new Librarian();                
            }
            
            if(e.getSource()==i3) {
                new Help();                
            }
            if(e.getSource()==i4) {
                new ViewEBooks();                
            }
        }

    
    public static void main(String[] args) {
        
        // TODO code application logic here
        LibraryManagement l=new LibraryManagement();
    }
    
}




