/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  SHAFAQUE RAHMAN
 * Created: 28 Nov, 2020
 */

USE library; 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE issued(
     call_no varchar(5) NOT NULL ,
     s_id varchar(30) NOT NULL, 
     s_name varchar(30) NOT NULL,
     s_mobile varchar(20) NOT NULL,
     issue_date varchar(30) NOT NULL ,
     last_date varchar(30) NOT NULL,
--      fine int NOT NULL,
     ret_status varchar(10) DEFAULT "No",
     reissued varchar(10) DEFAULT "No"

     
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE issued ADD PRIMARY KEY(call_no,s_id);

commit;