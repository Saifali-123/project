package librarymanagement;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class Help extends JFrame implements ActionListener{
    JFrame jf;
    JLabel l1,l2;
    JTextField t1;
    JTextArea t2;
    JButton b1;
    public Help() {
        jf = new JFrame("Contact Admin");
        l1 = new JLabel("Email Id");
        t1 = new JTextField();
        l2 = new JLabel("Write Your Query Here:");
        t2 = new JTextArea();
        b1 = new JButton("SUBMIT");
        
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2.setFont(new Font("Serif", Font.BOLD, 20));
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        t1.setFont(new Font("Serif", Font.PLAIN, 20));
        t2.setFont(new Font("Serif", Font.PLAIN, 20));
        
        l1.setBounds(50,50,200,30);
        t1.setBounds(50,100,280,30);
        l2.setBounds(50,150,300,30);
        t2.setBounds(50,200,330,100);        
        b1.setBounds(150,330,120,35);

        b1.addActionListener(this);
        
                
        jf.add(l1);
        jf.add(t1);
        jf.add(l2);
        jf.add(t2);        
        jf.add(b1);
        
        jf.setSize(430,420);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);
    }
    
    Connection conn;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1) {

            String n1=t1.getText();
            String n2=t2.getText();
//            if((n1.equals("") || n2.equals("")==false)){
//                System.out.println(n1 +n2);
                  database(n1,n2);
//            }
        }
    }
    
    //Work on database library
    public void database(String n1, String n2) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //String sql = "INSERT INTO librarian(l_name,email,contact,address,password) VALUES(" +name+ "," +email+ "," +contact+ "," +address+ "," +pass+ ")"; VALUES(" + n + ")";
            String sql = "INSERT INTO queryDb(email,query) VALUES(?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1,n1);
            ps.setString(2,n2);
            int ins = ps.executeUpdate();

            Help h = new Help();
            JOptionPane.showMessageDialog(h,"Your query has been sent to the Admin");
            conn.close();
            jf.dispose();

        } catch (Exception ex) {
            System.out.println(ex);
        }
        
    }

    public static void main(String args[]) {
        Help c = new Help();
    }
    
}