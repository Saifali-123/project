/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  SHAFAQUE RAHMAN
 * Created: 28 Nov, 2020
 */

USE library; 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE ebook(
     call_no varchar(5) NOT NULL PRIMARY KEY,
     b_name varchar(100) NOT NULL, 
     author varchar(30) NOT NULL,
     publisher varchar(40) NOT NULL,
     file_url varchar(200) NOT NULL 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- alter table book add column issued int (5) default=0;

commit;