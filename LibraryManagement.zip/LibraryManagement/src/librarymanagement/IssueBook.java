/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;

import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
//import static javax.swing.text.html.HTML.Tag.SELECT;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import javax.swing.text.DateFormatter;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class IssueBook extends JFrame implements ActionListener {

    JFrame j;
    JLabel l1, l2, l3, l4, l5;
    JTextField t1, t2, t3, t4, t5;
    JButton b1;

    public IssueBook() {
        j = new JFrame("Issue Books");
        l1 = new JLabel("Call no");
        t1 = new JTextField();
        l2 = new JLabel("Student Id");
        t2 = new JTextField();
        l3 = new JLabel("Name");
        t3 = new JTextField();
        l4 = new JLabel("Mobile No");
        t4 = new JTextField();
        b1 = new JButton("ISSUE");

        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2.setFont(new Font("Serif", Font.BOLD, 20));
        l3.setFont(new Font("Serif", Font.BOLD, 20));
        l4.setFont(new Font("Serif", Font.BOLD, 20));
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        t1.setFont(new Font("Serif", Font.PLAIN, 20));
        t2.setFont(new Font("Serif", Font.PLAIN, 20));
        t3.setFont(new Font("Serif", Font.PLAIN, 20));
        t4.setFont(new Font("Serif", Font.PLAIN, 20));

        l1.setBounds(50, 50, 100, 30);
        t1.setBounds(150, 50, 200, 30);
        l2.setBounds(50, 100, 100, 30);
        t2.setBounds(150, 100, 200, 30);
        l3.setBounds(50, 150, 100, 30);
        t3.setBounds(150, 150, 200, 30);
        l4.setBounds(50, 200, 100, 30);
        t4.setBounds(150, 200, 200, 30);
        b1.setBounds(160, 270, 100, 35);

        b1.addActionListener(this);

        j.add(l1);
        j.add(t1);
        j.add(l2);
        j.add(t2);
        j.add(l3);
        j.add(t3);
        j.add(l4);
        j.add(t4);
        j.add(b1);

        j.setSize(430, 420);
        j.setLayout(null);
        j.setLocationRelativeTo(null);
        j.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        j.setVisible(true);

    }

    //Button action
    Connection conn;

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            String c = t1.getText();
            String s_id = t2.getText();
            String n = t3.getText();
            String m = t4.getText();
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                String sql = "SELECT COUNT(s_id),reissued from issued WHERE s_id ='" + s_id + "'";
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(sql);
                rs.next();
                int count = rs.getInt(1);
                String r = rs.getString(2);
                if (count >= 4) {
                    IssueBook ib2 = new IssueBook();
                    JOptionPane.showMessageDialog(ib2, "Sorry!Student has already issued 4 books");

                } //                else if (r.equals("Yes")) {
                //                    IssueBook ib3 = new IssueBook();
                //                    JOptionPane.showMessageDialog(ib3, "Sorry!This book is already Reissued Once.");
                //                }
                else {
                    database(c, s_id, n, m);
                }
                conn.close();
            } catch (Exception ex2) {
                System.out.println(ex2);
            }
        }
    }

    //Work on database library
    public void database(String cno, String id, String name, String mobile) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");

            String sql = "INSERT INTO issued(call_no,s_id,s_name,s_mobile,issue_date,last_date) VALUES(?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, cno);
            ps.setString(2, id);
            ps.setString(3, name);
            ps.setString(4, mobile);
            DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDateTime now1 = LocalDateTime.now();
            String d = now1.format(df);
            ps.setString(5, d);
            LocalDateTime ld = now1.plusDays(15);
            String date2 = ld.format(df);
            ps.setString(6, date2);
            int ins = ps.executeUpdate();

            j.dispose();

            IssueBook ib = new IssueBook();
            JOptionPane.showMessageDialog(ib, "Book has been issued to student with id=" + id);

            conn.close();
        } catch (Exception ex) {
            j.dispose();
            IssueBook ib4 = new IssueBook();
            JOptionPane.showMessageDialog(ib4, "Sorry!This book detail is invalid.Please enter valid details.");

            //System.out.println(ex);
        }
    }

    // Main Method
    public static void main(String args[]) {
        IssueBook isBook = new IssueBook();
    }
}
