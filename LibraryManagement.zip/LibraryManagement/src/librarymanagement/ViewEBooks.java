/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;

import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.table.*;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import javax.swing.SwingUtilities;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class ViewEBooks extends JFrame {

    JFrame jf;
    JTable t;
    JScrollPane sp;
    int k;
    JLabel l;
    JTextField a;
    JButton b;
    Connection conn;
    String path;

    public ViewEBooks() {
        jf = new JFrame("View EBooks");
        //
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");

            //get no of row in database
            String sql1 = "SELECT count(call_no) FROM ebook ";
            Statement statement1 = conn.createStatement();
            ResultSet result1 = statement1.executeQuery(sql1);
            result1.next();
            k = result1.getInt(1);
            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }

        //
        String[][] data = new String[k][5];
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");

            //get no of row in database
            String sql = "SELECT * FROM ebook ";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);

            //Comparing all the value of db and checking for unused one                                                                                                                                                                                                         
            String a1, a2, a3, a4, a5;
            int a, i = 0;
            while (result.next()) {
                a1 = result.getString("call_no");
                a2 = result.getString("b_name");
                a3 = result.getString("author");
                a4 = result.getString("publisher");
                a5 = result.getString("file_url");

//                
                data[i][0] = a1;
                data[i][1] = a2;
                data[i][2] = a3;
                data[i][3] = a4;
                data[i][4] = a5;
                i++;
            }

            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }

        String[] heading = {"Call No", "Name", "Author", "Publisher", "File"};

        t = new JTable(data, heading);
        t.setFont(new Font("Serif", Font.PLAIN, 20));
        t.setBounds(0, 0, 1000, 600);

        //Set header bold and colored
        JTableHeader th = t.getTableHeader();
        th.setBackground(Color.gray);
        th.setFont(new Font("Serif", Font.BOLD, 20));
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        //set column width
        t.getColumnModel().getColumn(0).setPreferredWidth(80);
        t.getColumnModel().getColumn(1).setPreferredWidth(270);
        t.getColumnModel().getColumn(2).setPreferredWidth(270);
        t.getColumnModel().getColumn(3).setPreferredWidth(220);
        t.getColumnModel().getColumn(4).setPreferredWidth(220);
//        t.getColumnModel().getColumn(5).setPreferredWidth(180);

        //set Row Height
        t.setRowHeight(40);
        t.setSize(1000,600);
        t.setPreferredScrollableViewportSize(t.getPreferredSize());
        sp = new JScrollPane(t);
        sp.setPreferredSize(new Dimension(1080,550));
        l = new JLabel();
        a = new JTextField();
        b = new JButton("OPEN");
        l.setBounds(20, 550, 1080, 50);
        a.setBounds(20, 600, 170, 40);
        b.setBounds(220, 600, 150, 40);
        l.setText("Enter call no of book You want to open");
        l.setFont(new Font("Serif", Font.BOLD, 20));
        a.setFont(new Font("Serif", Font.BOLD, 25));
        b.setFont(new Font("Serif", Font.BOLD, 20));

        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (Desktop.isDesktopSupported()) {
                    String c = a.getText();
                    try {
                        Class.forName("com.mysql.jdbc.Driver");
                        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");

                        String sql = "SELECT file_url FROM ebook where call_no='" + c + "'";
                        Statement statement = conn.createStatement();
                        ResultSet result = statement.executeQuery(sql);
                        result.next();
                        path = result.getString(1);
                        conn.close();

                    } catch (Exception ex) {
                        System.out.println(ex);
                    }
                    try {
                        File myFile = new File(path);
                        Desktop.getDesktop().open(myFile);
                        //  b.setText("Opening...");

                    } catch (IOException ex) {
                    }
                }

            }
        });
        a.setHorizontalAlignment(JTextField.CENTER);
        jf.add(l);
        jf.add(a);
        jf.add(b);
        jf.add(sp);

        jf.pack();
        jf.setSize(1093, 700);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);

    }

    public static void main(String args[]) {
        ViewEBooks viewEBooks = new ViewEBooks();
    }
}
