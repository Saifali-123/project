package librarymanagement;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import java.sql.*;
import java.util.EventListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package librarymanagement;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class LibrarianWork extends JFrame implements ActionListener {

    /**
     * @param args the command line arguments
     */
    
    JFrame jf;
    JMenuBar mb;
    JMenu m1,m8,m9;
    JLabel l1;
    JMenuItem mi,m2,m3,m4,m5,m6,m7,m10,m11,m12,m13,m14;
    String name,pass;
//    public void paint(Graphics g) {  
//        Toolkit t=Toolkit.getDefaultToolkit();  
//        Image i=t.getImage("librarymanagement\\lib.jpg");  
//        g.drawImage(i, 0,0,500,500,null);  
//    }
    public LibrarianWork(String name,String password) {
        this.name=name;
        this.pass=password;
        jf=new JFrame("Booking Page ");
        m1=new JMenu("Home");
        m2=new JMenuItem("Add Books");
        m3=new JMenuItem("Delete Books");
        m4=new JMenuItem("Edit Books");
        m5=new JMenuItem("View Books");
        m6=new JMenuItem("Issue Books");
        m7=new JMenuItem("View Issued Books");
        m11=new JMenuItem("Add EBooks");
        m12=new JMenuItem("Re-Issue Books");
        m13=new JMenuItem("Return Books");
        m14=new JMenuItem("Edit E-Books");
        m8=new JMenu("Books");
        m9=new JMenu("LogOut");
        mi=new JMenuItem("Home Page");
        m10=new JMenuItem("Click here");
        
        m1.add(mi);
        m8.add(m2);
        m8.add(m3);
        m8.add(m4);
        m8.add(m5);
        m8.add(m6);
        m8.add(m7);
        m8.add(m11);
        m8.add(m12);
        m8.add(m13);
        m8.add(m14);

        m9.add(m10);

        mb=new JMenuBar();
        mb.add(m1);
        mb.add(m8);
        mb.add(m9);
        
       
        jf.setJMenuBar(mb);
        
        jf.setContentPane(new JLabel(new ImageIcon("C:\\Users\\SHAFAQUE RAHMAN\\Documents\\NetBeansProjects\\LibraryManagement\\src\\librarymanagement\\lib2.jpg")));
        JLabel l=new JLabel("Librarian Work");
        l.setBounds(270,10,500,100);
        jf.add(l);
        l.setFont(new Font("Serif", Font.BOLD, 36));
        l.setForeground(Color.GRAY);

        
        mi.addActionListener(this);
        m2.addActionListener(this);
        m3.addActionListener(this);
        m4.addActionListener(this);
        m5.addActionListener(this);
        m6.addActionListener(this);
        m7.addActionListener(this);
        m10.addActionListener(this);
        m11.addActionListener(this);
        m12.addActionListener(this);
        m13.addActionListener(this);
        m14.addActionListener(this);
       
                
        jf.setVisible(true);
        jf.setSize(800,500);
        
        //To center the frame in window screen
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    @Override 
    public void actionPerformed(ActionEvent e) {
            if(e.getSource()==mi) {
                 jf.dispose();
                 new LibraryManagement();
            }
            if(e.getSource()==m2) {
                  new AddBook();
                
            }
            if(e.getSource()==m3) {
                new DeleteBook();                
            }
            if(e.getSource()==m4) {
                 new EditBook();
            }
            if(e.getSource()==m5) {
                 new ViewBook();
            }
            if(e.getSource()==m6) {
                 new IssueBook();
            }
            if(e.getSource()==m7) {
                 new ViewIssuedBook();
            }
             if(e.getSource()==m11) {
                 new AddEBooks();
            }
            if(e.getSource()==m12) {
                 new ReIssueBook();
            }
            if(e.getSource()==m13) {
                 new ReturnBook();
            } 
            if(e.getSource()==m14) {
                 new EditEBook();
            }           
            if(e.getSource()==m10) {
                 new LibrarianLogout(name,pass);
                 jf.dispose();
                 new LibraryManagement();
            }
        }

   // Main Method
    public static void main(String[] args) {
        
        // TODO code application logic here
        LibrarianWork l=new LibrarianWork("","");
    }
//    
}




