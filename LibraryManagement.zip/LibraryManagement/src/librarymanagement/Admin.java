/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
import java.awt.*;
//import java.awt.event*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.sql.*;
import javax.swing.JOptionPane;

public class Admin extends JFrame implements ActionListener  {
    JFrame j;
    JLabel l1,l2;
    JTextField t1; 
    JPasswordField p1;
    JButton b1,b2,b3;
    private Component adWork;
    public Admin() {
        j=new JFrame("Admin Login");
        l1=new JLabel("Username");
        l2=new JLabel("Password");
        t1=new JTextField();
        p1=new JPasswordField();
        b1=new JButton("Reset");
        b2=new JButton("Submit");
        b3=new JButton("Close");
        j.setLayout(null);
        l1.setBounds(40,40,200,40);
        l2.setBounds(40,120,200,40);
        t1.setBounds(170,40,240,40);
        p1.setBounds(170,120,240,40);
        b1.setBounds(50,230,100,40);
        b2.setBounds(180,230,100,40);
        b3.setBounds(310,230,100,40);
        l1.setFont(new Font("Serif", Font.PLAIN, 22));
        l2.setFont(new Font("Serif", Font.PLAIN, 22));
        t1.setFont(new Font("Serif", Font.PLAIN, 22));
        p1.setFont(new Font("Serif", Font.PLAIN, 22));
        t1.setForeground(Color.BLUE);
        p1.setForeground(Color.BLUE);
        j.add(l1);
        j.add(t1);
        j.add(l2);
        j.add(p1);
        j.add(b1);
        j.add(b2);
        j.add(b3);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);

        //j.setBackground(Color.RED);

        j.setVisible(true);
        j.setSize(500,400);
        j.setLocationRelativeTo(null);

        j.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    
  @Override 
    public void actionPerformed(ActionEvent ae) {
         
    if (ae.getSource()==b1) {
        t1.setText(" ");
        p1.setText(null);
    }
    if(ae.getSource()==b3) {
//        System.exit(0);
          new LibraryManagement();
    }
    if(ae.getSource()==b2) {
        String user = t1.getText();
        String pass = p1.getText();
        if(user.equals("shafaque") && pass.equals("sr2001")){
            t1.setText("");
            p1.setText("");
            b2.setText("Done");
            database(user,pass);
            j.dispose();  
            new AdminWork();
//            adWork = new AdminWork(); 
//            j.add(adWork);
        } else{
            System.out.println("Invalid username or password!!!");
        }
//        try {
//        Conn c1=new Conn();
//        String s1=t1.getText();
//        String s2=p1.getText();
//        String str= "SELECT * FROM login WHERE username='"+s1+"'and password='"+s2+"'";
//        ResultSet rs=c1.executeQuery("SELECT * FROM login WHERE username='"+s1+"'and password='"+s2+"'");
//        if(rs.next()) {
//            new AdminWork();
//            j.setVisible(false);
//        }
//        else {
//            jOptionPane.showMessageDialog(null,"Invalid Login");
//
//        }
//        }catch(Exception e) {
//            
//        }
    }
  }
    //Work on database
    public void database(String name,String pass) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //String sql = "INSERT INTO librarian(l_name,email,contact,address,password) VALUES(" +name+ "," +email+ "," +contact+ "," +address+ "," +pass+ ")"; VALUES(" + n + ")";
            String sql = "INSERT INTO adminLogin(A_name,password) VALUES(?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1,name);
            ps.setString(2,pass);
            
            int ins = ps.executeUpdate();
            
            
            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
//     Main Method
    public static void main(String args[]) {
        Admin a=new Admin();
    }
}


        