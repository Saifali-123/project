package librarymanagement;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;
import javax.swing.ImageIcon;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class EditEBook extends JFrame implements ActionListener{
    JFrame jf;
    JLabel l,l1,l2,l3,l4,l5;
    JTextField t,t1,t2,t3,t4,t5;
    JButton b,b1;
    ImageIcon icon;

    public EditEBook() {
        jf = new JFrame("Edit Book");
        l  = new JLabel("Call No");
        t  = new JTextField();
        icon = new ImageIcon("C:\\Users\\SHAFAQUE RAHMAN\\Documents\\NetBeansProjects\\LibraryManagement\\src\\librarymanagement\\timer.jpg");
        b  = new JButton(icon);
        l1 = new JLabel("Name");
        t1 = new JTextField();
        l2 = new JLabel("Author");
        t2 = new JTextField();
        l3 = new JLabel("Publisher");
        t3 = new JTextField();
        l4 = new JLabel("File Url");
        t4 = new JTextField();
        b1 = new JButton("UPDATE");
        
        
        // Set image to size of JButton...
       // int offset = b.getInsets().left;
        b.setIcon(resizeIcon(icon, 40,36));
        
        t.setHorizontalAlignment(SwingConstants.CENTER);

        
        l.setFont(new Font("Serif", Font.BOLD, 20));
        t.setFont(new Font("Serif", Font.PLAIN, 20));
        b.setFont(new Font("Serif", Font.BOLD, 20));
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2.setFont(new Font("Serif", Font.BOLD, 20));
        l3.setFont(new Font("Serif", Font.BOLD, 20));
        l4.setFont(new Font("Serif", Font.BOLD, 20));
        //l5.setFont(new Font("Serif", Font.BOLD, 20));
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        t1.setFont(new Font("Serif", Font.PLAIN, 20));
        t2.setFont(new Font("Serif", Font.PLAIN, 20));
        t3.setFont(new Font("Serif", Font.PLAIN, 20));
        t4.setFont(new Font("Serif", Font.PLAIN, 20));
      //  t5.setFont(new Font("Serif", Font.PLAIN, 20));
               
        l.setBounds(50,50,100,30);
        t.setBounds(150,50,250,30);
        b.setBounds(50,100,40,35);
        l1.setBounds(50,150,100,30);
        t1.setBounds(150,150,250,30);
        l2.setBounds(50,200,100,30);
        t2.setBounds(150,200,250,30);
        l3.setBounds(50,250,100,30);
        t3.setBounds(150,250,250,30);
        l4.setBounds(50,300,100,30);
        t4.setBounds(150,300,250,30);
       // l5.setBounds(50,350,100,30);
       // t5.setBounds(150,350,250,30);
        b1.setBounds(190,400,115,35);

        b.addActionListener(this);
        b1.addActionListener(this);
        
        jf.add(l);
        jf.add(t);
        jf.add(b);
        jf.add(l1);
        jf.add(t1);
        jf.add(l2);
        jf.add(t2);
        jf.add(l3);
        jf.add(t3);
        jf.add(l4);
        jf.add(t4);
        //jf.add(l5);
       // jf.add(t5);
        jf.add(b1);
        
        jf.setSize(480,500);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);


    }
    
     Connection conn;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b) {
            String c=t.getText();
           // int n1=Integer.parseInt(n);
            database(c);
        }
        
        if(e.getSource()==b1) {
            String c=t.getText();
           // int id=Integer.parseInt(n3);
            String n=t1.getText();
            String a=t2.getText();
            String p=t3.getText();
            //BigInteger c=new BigInteger(c1);
            String q=t4.getText();
           // String p=t5.getText();
            database2(c,n,a,p,q);
        }
    }
    
    //Work on database library
    public void database(String c) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            String sql = "SELECT * FROM ebook where call_no='"+c+"'";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);

            //Comparing all the value of db and checking for unused one                                                                                                                                                                                                         
            String a1,a2,a3,a4;
            while (result.next()) {
                 a1 = result.getString("b_name");
                 a2 = result.getString("author");
                 a3 = result.getString("publisher");
                 a4 = result.getString("file_url");
                 t1.setText(a1);
                 t2.setText(a2);
                 t3.setText(a3);
                 t4.setText(a4);
            }
            

              conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
    //Work on database library
    public void database2(String call,String name,String author,String publisher,String url) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //String sql = "INSERT INTO librarian(l_name,email,contact,address,password) VALUES(" +name+ "," +email+ "," +contact+ "," +address+ "," +pass+ ")"; VALUES(" + n + ")";
            String sql2 = "UPDATE ebook SET b_name='"+name+"',author='"+author+"',publisher='"+publisher+"',file_url='"+url+"' where call_no='"+call+"'";
            PreparedStatement ps = conn.prepareStatement(sql2);
            int ins = ps.executeUpdate();
            
            jf.dispose();
            EditEBook eb2 = new EditEBook();
            JOptionPane.showMessageDialog(eb2,"Book details has been updated with call_no = "+call);

            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
    private static Icon resizeIcon(ImageIcon icon, int resizedWidth, int resizedHeight) {
    Image img = icon.getImage();  
    Image resizedImage = img.getScaledInstance(resizedWidth, resizedHeight,  java.awt.Image.SCALE_SMOOTH);  
    return new ImageIcon(resizedImage);
}
    
    public static void main(String args[]) {
        EditEBook editEBook = new EditEBook();
    }
}