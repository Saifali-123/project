/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.math.BigInteger;
import java.io.File;
import java.io.FileReader;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class AddEBooks extends JFrame implements ActionListener{
    JFrame j;
    JLabel l1,l2,l3,l4,l5;
    JTextField t1,t2,t3,t4,t5;
    JButton b1,b2;
    public AddEBooks() {
        j = new JFrame("Add E-Books");
        l1 = new JLabel("Call no");
        t1 = new JTextField();
        l2 = new JLabel("Name");
        t2 = new JTextField();
        l3 = new JLabel("Author");
        t3 = new JTextField();
        l4 = new JLabel("Publisher");
        t4 = new JTextField();
        l5 = new JLabel("File");
        t5 = new JTextField();
        b1 = new JButton("SAVE");
        b2 = new JButton("Browse");
        
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2.setFont(new Font("Serif", Font.BOLD, 20));
        l3.setFont(new Font("Serif", Font.BOLD, 20));
        l4.setFont(new Font("Serif", Font.BOLD, 20));
        l5.setFont(new Font("Serif", Font.BOLD, 20));
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        b2.setFont(new Font("Serif", Font.BOLD, 20));
        t1.setFont(new Font("Serif", Font.PLAIN, 20));
        t2.setFont(new Font("Serif", Font.PLAIN, 20));
        t3.setFont(new Font("Serif", Font.PLAIN, 20));
        t4.setFont(new Font("Serif", Font.PLAIN, 20));
        t5.setFont(new Font("Serif", Font.PLAIN, 20));
               
        l1.setBounds(50,50,100,30);
        t1.setBounds(150,50,200,30);
        l2.setBounds(50,100,100,30);
        t2.setBounds(150,100,200,30);
        l3.setBounds(50,150,100,30);
        t3.setBounds(150,150,200,30);
        l4.setBounds(50,200,100,30);
        t4.setBounds(150,200,200,30);
        l5.setBounds(50,250,100,30);
        t5.setBounds(150,250,200,30);
        b2.setBounds(360,250,100,30);        
        b1.setBounds(160,310,100,35);

        b1.addActionListener(this);
        b2.addActionListener(this);
        j.add(l1);
        j.add(t1);
        j.add(l2);
        j.add(t2);
        j.add(l3);
        j.add(t3);
        j.add(l4);
        j.add(t4);
        j.add(l5);
        j.add(t5);
        j.add(b1);
        j.add(b2);
        
        j.setSize(490,420);
        j.setLayout(null);
        j.setLocationRelativeTo(null);
        j.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        j.setVisible(true);


    }
    
    //Button action
    Connection conn;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1) {
            String n=t1.getText();
            String em=t2.getText();
            String c=t3.getText();
            //BigInteger c=new BigInteger(c1);
            String ad=t4.getText();
            String p=t5.getText();
            database(n,em,c,ad,p);
        }
        if(e.getSource()==b2){    
    JFileChooser fc=new JFileChooser();    
    int i=fc.showOpenDialog(this);    
    if(i==JFileChooser.APPROVE_OPTION){    
        File f=fc.getSelectedFile();    
        String filepath=f.getPath(); 
        String filename=f.getName();    
//        try{  
//        BufferedReader br=new BufferedReader(new FileReader(filepath));    
//        String s1="",s2="";                         
//        while((s1=br.readLine())!=null){    
//        s2+=s1+"\n";    
//        }    
//        t5.setText(s2);    
//        br.close();    
//        }catch (Exception ex) {ex.printStackTrace();  }        
          
          t5.setText(filepath);
    }    
        }    
          
    }
    
    //Work on database library
    public void database(String cno,String name,String author,String publisher,String file_url) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //String sql = "INSERT INTO librarian(l_name,email,contact,address,password) VALUES(" +name+ "," +email+ "," +contact+ "," +address+ "," +pass+ ")"; VALUES(" + n + ")";
            String sql = "INSERT INTO ebook(call_no,b_name,author,publisher,file_url) VALUES(?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1,cno);
            ps.setString(2,name);
            ps.setString(3,author);
            ps.setString(4,publisher);
            ps.setString(5,file_url);
            int ins = ps.executeUpdate();
            
            j.dispose();

            AddEBooks ab = new AddEBooks();
            JOptionPane.showMessageDialog(ab,"EBook details has been inserted ");

            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    
    // Main Method
    public static void main(String args[]) {
        AddEBooks addEBook = new AddEBooks();
    }
}
