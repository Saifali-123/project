/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
import java.awt.*;
//import java.awt.event*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.sql.*;
import javax.swing.JOptionPane;

public class Librarian extends JFrame implements ActionListener {

    JFrame j;
    JLabel l1, l2;
    JTextField t1;
    JPasswordField p1;
    JButton b1, b2, b3;

    public Librarian() {
        j = new JFrame("Librarian Login");
        l1 = new JLabel("Username");
        l2 = new JLabel("Password");
        t1 = new JTextField();
        p1 = new JPasswordField();
        b1 = new JButton("Reset");
        b2 = new JButton("Submit");
        b3 = new JButton("Close");
        j.setLayout(null);
        l1.setBounds(40, 40, 200, 40);
        l2.setBounds(40, 120, 200, 40);
        t1.setBounds(170, 40, 240, 40);
        p1.setBounds(170, 120, 240, 40);
        b1.setBounds(50, 230, 100, 40);
        b2.setBounds(180, 230, 100, 40);
        b3.setBounds(310, 230, 100, 40);
        l1.setFont(new Font("Serif", Font.PLAIN, 22));
        l2.setFont(new Font("Serif", Font.PLAIN, 22));
        t1.setFont(new Font("Serif", Font.PLAIN, 22));
        p1.setFont(new Font("Serif", Font.PLAIN, 22));
        t1.setForeground(Color.BLUE);
        p1.setForeground(Color.BLUE);
        j.add(l1);
        j.add(t1);
        j.add(l2);
        j.add(p1);
        j.add(b1);
        j.add(b2);
        j.add(b3);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);

        //j.setBackground(Color.RED);
        j.setVisible(true);
        j.setSize(500, 400);
        j.setLocationRelativeTo(null);

        j.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    Connection conn;

    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == b1) {
            t1.setText(" ");
            p1.setText(null);
        }
        if (ae.getSource() == b3) {
            //System.exit(0);
            new LibraryManagement();
        }
        if (ae.getSource() == b2) {
            String s1 = t1.getText();
            String s2 = p1.getText();
            database(s1, s2);
        }
    }

    //Work on database library
    public void database(String name, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");

            String sql1 = "SELECT L_name FROM librarianLogin where password='" + password + "'";
            Statement statement1 = conn.createStatement();
            ResultSet result1 = statement1.executeQuery(sql1);
//            if(!result1.next())
//            {
//                Librarian l1 = new Librarian();
//                JOptionPane.showMessageDialog(l1,"Wrong Username or Password");
//                j.dispose();
//            }
            if (result1.next()) {
                String n2 = result1.getString(1);
               // System.out.println(n2);
                if (n2.equals(name)) {
                    new LibrarianWork(name, password);
                    j.dispose();
                }
            } else {

                String sql = "SELECT L_name FROM librarian where password='" + password + "'";
                Statement statement = conn.createStatement();
                ResultSet result = statement.executeQuery(sql);

                if (!result.next()) {
                    Librarian l1 = new Librarian();
                    JOptionPane.showMessageDialog(l1, "Wrong Username or Password");
                    j.dispose();
                }
                String n = result.getString(1);
                System.out.println(n);
                if (n.equals(name)) {
                    String sql2 = "INSERT INTO librarianLogin(l_name,password) VALUES(?,?)";
                    PreparedStatement ps = conn.prepareStatement(sql2);
                    ps.setString(1, name);
                    ps.setString(2, password);
                    int ins = ps.executeUpdate();

                    new LibrarianWork(name, password);
                    j.dispose();
                } else {
                    Librarian l1 = new Librarian();
                    JOptionPane.showMessageDialog(l1, "Wrong Username or Password");
                    j.dispose();
                }
            }
            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static void main(String args[]) {
        Librarian a = new Librarian();
    }
}
