package librarymanagement;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class DeleteLibrarian extends JFrame implements ActionListener{
    JFrame jf;
    JLabel l1,l2;
    JTextField t1;
    JButton b1;
    public DeleteLibrarian() {
        jf = new JFrame("Delete Librarian");
        l1 = new JLabel("Librarian Id");
        t1 = new JTextField();
        l2 = new JLabel("<html>Note:Librarian id was given at <br>the time of registration.</html>",SwingConstants.CENTER);
        b1 = new JButton("DELETE");
        
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2.setFont(new Font("Serif", Font.BOLD, 20));
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        t1.setFont(new Font("Serif", Font.PLAIN, 20));
        
        l1.setBounds(50,50,200,30);
        t1.setBounds(50,100,200,30);
        b1.setBounds(50,150,120,35);
        l2.setBounds(50,200,300,60);

        b1.addActionListener(this);
        
        jf.add(l1);
        jf.add(t1);
        jf.add(b1);
        jf.add(l2);
        
        jf.setSize(430,420);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);
    }
    
    Connection conn;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1) {
            String n=t1.getText();
            int n1=Integer.parseInt(n);
            database(n1);
        }
    }
    
    //Work on database library
    public void database(int n) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //String sql = "INSERT INTO librarian(l_name,email,contact,address,password) VALUES(" +name+ "," +email+ "," +contact+ "," +address+ "," +pass+ ")"; VALUES(" + n + ")";
            String sql = "DELETE FROM librarian where L_id="+n;
            PreparedStatement ps = conn.prepareStatement(sql);          
            int ins = ps.executeUpdate();
            
            jf.dispose();
            DeleteLibrarian dl2 = new DeleteLibrarian();
            JOptionPane.showMessageDialog(dl2,"This Librarian details has been deleted from Library database ");

              conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
    public static void main(String args[]) {
        DeleteLibrarian delLib = new DeleteLibrarian();
    }
    
}