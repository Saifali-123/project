/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  SHAFAQUE RAHMAN
 * Created: 28 Nov, 2020
 */

USE library; 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE librarian(
     L_id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
     L_name varchar(30) NOT NULL, 
     email varchar(30) NOT NULL,
     contact varchar(10) NOT NULL,
     address varchar(40) NOT NULL,
     password varchar(30) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


commit;