/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class AdminLogout {
    Connection conn;
    public AdminLogout() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            
            
            String sql1 = "DELETE FROM adminLogin where password='sr2001'";
            PreparedStatement ps = conn.prepareStatement(sql1);
            int p = ps.executeUpdate(sql1);
            
            //AddLibrarian al2 = new AddLibrarian();
           // JOptionPane.showMessageDialog(al2,"Librarian details has been inserted with id = "+v);

            conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    public static void main(String args[]) {
        AdminLogout adLogout = new AdminLogout();
    }

}
