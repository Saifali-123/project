package librarymanagement;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class ReturnBook extends JFrame implements ActionListener{
    JFrame jf;
    JLabel l1,l2;
    JTextField t1,t2;
    JButton b1;
    public ReturnBook() {
        jf = new JFrame("Return Book");
        l1 = new JLabel("Call no");
        t1 = new JTextField();
        l2 = new JLabel("Student Id");
        t2 = new JTextField();
       // l2 = new JLabel("<html>Note:Librarian id was given at <br>the time of registration.</html>",SwingConstants.CENTER);
        b1 = new JButton("Return");
        
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2.setFont(new Font("Serif", Font.BOLD, 20));
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        t1.setFont(new Font("Serif", Font.PLAIN, 20));
        t2.setFont(new Font("Serif", Font.PLAIN, 20));

        l1.setBounds(50,50,200,30);
        t1.setBounds(50,100,200,30);
        b1.setBounds(50,270,120,35);
        l2.setBounds(50,150,200,30);
        t2.setBounds(50,200,200,30);

        b1.addActionListener(this);
        
        jf.add(l1);
        jf.add(t1);
        jf.add(l2);
        jf.add(t2);
        jf.add(b1);
        
        jf.setSize(430,420);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);
    }
    
    Connection conn;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1) {
            String n1=t1.getText();
            String n2=t2.getText();
           // int n1=Integer.parseInt(n);
            database(n1,n2);
        }
    }
    
    //Work on database library
    public void database(String n1,String n2) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //String sql = "INSERT INTO librarian(l_name,email,contact,address,password) VALUES(" +name+ "," +email+ "," +contact+ "," +address+ "," +pass+ ")"; VALUES(" + n + ")";
            String sql = "UPDATE issued SET ret_status='Yes' where call_no='"+n1+"' and s_id='"+n2+"'";
            PreparedStatement ps = conn.prepareStatement(sql);          
            int ins = ps.executeUpdate();
            if(n1.equals(null) || n1.equals("") || n2.equals(null) || n2.equals("") ){
                jf.dispose();
                ReturnBook r2 = new ReturnBook();
                JOptionPane.showMessageDialog(r2,"Call no and student id is mandatory,please insert it for return book");
            }else {
                jf.dispose();
                ReturnBook r1 = new ReturnBook();
                JOptionPane.showMessageDialog(r1,"You have successfully return this book ");
            }
              conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
    public static void main(String args[]) {
        ReturnBook retBook = new ReturnBook();
    }
    
}