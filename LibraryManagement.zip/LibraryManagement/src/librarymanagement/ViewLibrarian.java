/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagement;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.table.*;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;
import javax.swing.SwingUtilities;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class ViewLibrarian extends JFrame {
    JFrame jf;
    JTable t;
    JScrollPane sp;
    int k;
    public ViewLibrarian() {
        jf = new JFrame("View Librarian");
        //
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //get no of row in database
            String sql1 = "SELECT count(L_id) FROM librarian ";
            Statement statement1 = conn.createStatement();
            ResultSet result1 = statement1.executeQuery(sql1);
            result1.next();
            k=result1.getInt(1);
           conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
        //
        
        String[][] data = new String[k][6];
         try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //get no of row in database
//            String sql1 = "SELECT count(L_id) FROM librarian ";
//            Statement statement1 = conn.createStatement();
//            ResultSet result1 = statement1.executeQuery(sql1);
//            result1.next();
//            int k=result1.getInt(1);

            
            
            
            String sql = "SELECT * FROM librarian ";
            Statement statement = conn.createStatement();
            ResultSet result = statement.executeQuery(sql);

            //Comparing all the value of db and checking for unused one                                                                                                                                                                                                         
           
            String a1,a2,a3,a4,a5,a6;
            int a,i=0;
            while (result.next()) {
                 a = result.getInt("L_id");
                 a1  = String.valueOf(a);
                 a2 = result.getString("L_name");
                 a3 = result.getString("email");
                 a4 = result.getString("contact");
                 a5 = result.getString("address");
                 a6 = result.getString("password");    
                 
                 
                 data[i][0]=a1;
                 data[i][1]=a2;
                 data[i][2]=a3;
                 data[i][3]=a4;
                 data[i][4]=a5;
                 data[i][5]=a6;
                 i++;
            }
            
              conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        
        
        
        String[] heading = {"Id","Name","Email","Contact","Address","Password"};
        

        t  = new JTable(data,heading);
        t.setFont(new Font("Serif",Font.PLAIN,20));
        t.setBounds(0,0,1000,1000);
        
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        //Set header bold and colored
        JTableHeader th = t.getTableHeader();
        th.setBackground(Color.gray);
        th.setFont(new Font("Serif", Font.BOLD, 20));
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        

        //set column width
        t.getColumnModel().getColumn(0).setPreferredWidth(70);
        t.getColumnModel().getColumn(1).setPreferredWidth(250);
        t.getColumnModel().getColumn(2).setPreferredWidth(250);
        t.getColumnModel().getColumn(3).setPreferredWidth(170);
        t.getColumnModel().getColumn(4).setPreferredWidth(250);
        t.getColumnModel().getColumn(5).setPreferredWidth(150);
        
        //set Row Height
        t.setRowHeight(35);
        //t.setSize(600,400);
        t.setPreferredScrollableViewportSize(t.getPreferredSize());
        sp =  new JScrollPane(t);
        jf.add(sp);
       
        jf.pack();
       // jf.setSize(883,876);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);


    }
    
    public static void main(String args[]) {
        ViewLibrarian viewLib = new ViewLibrarian();
    }
}
