/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  SHAFAQUE RAHMAN
 * Created: 28 Nov, 2020
 */

USE libraries; 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE book(
     call_no varchar(5) NOT NULL PRIMARY KEY,
     b_name varchar(30) NOT NULL, 
     author varchar(30) NOT NULL,
     publisher varchar(40) NOT NULL,
     quantity int(10) NOT NULL 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

alter table book add column issued int (5) default=0;

commit;