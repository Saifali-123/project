package librarymanagement;
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.math.BigInteger;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class DeleteBook extends JFrame implements ActionListener{
    JFrame jf;
    JLabel l1,l2;
    JTextField t1;
    JButton b1;
    public DeleteBook() {
        jf = new JFrame("Delete Book");
        l1 = new JLabel("Call no");
        t1 = new JTextField();
       // l2 = new JLabel("<html>Note:Librarian id was given at <br>the time of registration.</html>",SwingConstants.CENTER);
        b1 = new JButton("DELETE");
        
        l1.setFont(new Font("Serif", Font.BOLD, 20));
//        l2.setFont(new Font("Serif", Font.BOLD, 20));
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        t1.setFont(new Font("Serif", Font.PLAIN, 20));
        
        l1.setBounds(50,50,200,30);
        t1.setBounds(50,100,200,30);
        b1.setBounds(50,150,120,35);
//        l2.setBounds(50,200,300,60);

        b1.addActionListener(this);
        
        jf.add(l1);
        jf.add(t1);
        jf.add(b1);
//        jf.add(l2);
        
        jf.setSize(430,420);
        jf.setLayout(null);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jf.setVisible(true);
    }
    
    Connection conn;
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1) {
            String n1=t1.getText();
           // int n1=Integer.parseInt(n);
            database(n1);
        }
    }
    
    //Work on database library
    public void database(String n) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/libraries", "root", "");
                
            //String sql = "INSERT INTO librarian(l_name,email,contact,address,password) VALUES(" +name+ "," +email+ "," +contact+ "," +address+ "," +pass+ ")"; VALUES(" + n + ")";
            String sql = "DELETE FROM book where call_no='"+n+"'";
            PreparedStatement ps = conn.prepareStatement(sql);          
            int ins = ps.executeUpdate();
            if(n.equals(null) || n.equals("")){
                jf.dispose();
                DeleteBook dl2 = new DeleteBook();
                JOptionPane.showMessageDialog(dl2,"Call no is mandatory,please insert it for deletion");
            }else {
                jf.dispose();
                DeleteBook dl = new DeleteBook();
                JOptionPane.showMessageDialog(dl,"This Book details has been deleted from Library database ");
            }
              conn.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
    public static void main(String args[]) {
        DeleteBook delBook = new DeleteBook();
    }
    
}