package librarymanagement;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import java.sql.*;
import java.util.EventListener;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package librarymanagement;

/**
 *
 * @author SHAFAQUE RAHMAN
 */
public class AdminWork extends JFrame implements ActionListener {

    /**
     * @param args the command line arguments
     */
    
    JFrame jf;
    JMenuBar mb;
    JMenu m1,m6,m8;
    JLabel l1;
    JMenuItem mi,m2,m3,m4,m5,m7;
//    public void paint(Graphics g) {  
//        Toolkit t=Toolkit.getDefaultToolkit();  
//        Image i=t.getImage("librarymanagement\\lib.jpg");  
//        g.drawImage(i, 0,0,500,500,null);  
//    }
    public AdminWork() {
        jf=new JFrame("Library Admin Page ");
        m1=new JMenu("Home");
        m2=new JMenuItem("Add Librarian");
        m3=new JMenuItem("Delete Librarian");
        m4=new JMenuItem("Edit Librarian");
        m5=new JMenuItem("View Librarian");
        m6=new JMenu("Logout");
        m7=new JMenuItem("Click Here");
        m8=new JMenu("Librarian");
        mi=new JMenuItem("Home Page");
        
        m1.add(mi);
        m6.add(m7);
        m8.add(m2);
        m8.add(m3);
        m8.add(m4);
        m8.add(m5);

        mb=new JMenuBar();
        mb.add(m1);
        mb.add(m8);
        mb.add(m6);
        
       
        jf.setJMenuBar(mb);
        
        jf.setContentPane(new JLabel(new ImageIcon("C:\\Users\\SHAFAQUE RAHMAN\\Documents\\NetBeansProjects\\LibraryManagement\\src\\librarymanagement\\lib2.jpg")));
        JLabel l=new JLabel("Administrative Work");
        l.setBounds(270,10,500,100);
        jf.add(l);
        l.setFont(new Font("Serif", Font.BOLD, 36));
        l.setForeground(Color.GRAY);

        
        mi.addActionListener(this);
        m2.addActionListener(this);
        m3.addActionListener(this);
        m4.addActionListener(this);
        m5.addActionListener(this);
        m7.addActionListener(this);
        
        
                
        jf.setVisible(true);
        jf.setSize(800,500);
        
        //To center the frame in window screen
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    @Override 
    public void actionPerformed(ActionEvent e) {
            if(e.getSource()==mi) {
                 jf.dispose();
                 new LibraryManagement();
            }
            if(e.getSource()==m2) {
               // jf.dispose();
                new AddLibrarian();

//                jf.add(addLib);
//                jf.setVisible(false);
            }
            if(e.getSource()==m3) {
                new DeleteLibrarian();                
            }
            if(e.getSource()==m4) {
                 new EditLibrarian();
            }
            if(e.getSource()==m5) {
                 new ViewLibrarian();
            }
            if(e.getSource()==m7) {
                 new AdminLogout();
                 jf.dispose();
                 new LibraryManagement();
            }
        }

   // Main Method
    public static void main(String[] args) {
        
        // TODO code application logic here
        Component a=new AdminWork();
    }
//    
}




