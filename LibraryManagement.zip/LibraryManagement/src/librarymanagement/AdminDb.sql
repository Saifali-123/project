/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  SHAFAQUE RAHMAN
 * Created: 28 Nov, 2020
 */

USE library; 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE adminLogin(
     A_name varchar(30) NOT NULL,
     password varchar(30) NOT NULL PRIMARY KEY 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


commit;