<?php 
   $apikey="rzp_test_TqNL9XozC8zx8I"
?>
<script src="https://code.jquery.com/jquery-3.5.0.js"></script>
<form action="confirm.php" method="POST">
   <Script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $apikey; ?>"
	
	
	<!--var total2=0;
                  total2= sessionStorage.getItem("total");
                  total2=(total2*1)+18;
                  document.getElementById('amount').value=total2;-->
				  
    data-amount="<?php echo 22*100;?>" 
    data-currency="INR"
    
    data-button-text="pay with Razorpay"
    data-name="Resto"
    data-description="Resto Resturant"
    data-prefill.name="<?php echo $_POST['name'];?>"
    data-prefill.email="<?php echo $_POST['email'];?>"
    data-prefill.contact="<?php echo $_POST['mobile'];?>"
></script>

</form>
<style>
    .razorpay-payment-button {display:none;}
</style>


<script type="text/javascript">
    $(document).ready(function(){
        $('.razorpay-payment-button').click();
    });
    </script>
