<div class="footer">
            
            <div>
                <strong>Copyright @</strong> Resto &copy; 2022
            </div>
        </div>